#!/bin/bash
python3 backend/app.py